// Deprecated: renamed to CrashKartScratchCard. Kept as pass-through to avoid import breaks.
export { default } from './CrashKartScratchCard'
